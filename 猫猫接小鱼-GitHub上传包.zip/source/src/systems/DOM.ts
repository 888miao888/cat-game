// DOM 覆盖层（HUD / 菜单 / 结算）——按 skill 规范，菜单与文字 HUD 走 DOM 而非画布
export const ui = {
  bindStart(cb: () => void): void {
    document.getElementById('start-btn')!.addEventListener('click', cb);
  },
  showMenu(finalScore?: number): void {
    const overlay = document.getElementById('overlay')!;
    const hud = document.getElementById('hud')!;
    overlay.classList.remove('hidden');
    hud.classList.add('hidden');
    const panelTitle = document.getElementById('panel-title')!;
    const final = document.getElementById('final-score')!;
    const desc = document.getElementById('panel-desc')!;
    if (finalScore !== undefined) {
      panelTitle.textContent = '😿 游戏结束';
      desc.textContent = '再接再厉，猫咪等着吃鱼呢！';
      final.textContent = `本局得分：${finalScore}`;
      final.classList.remove('hidden');
    } else {
      panelTitle.textContent = '🐱 猫猫接小鱼';
      desc.innerHTML = '← → 或 A / D 移动猫猫，按住鼠标拖动也可以<br />接小鱼 +10 分，金鱼 +50 分，小心炸弹 💣';
      final.classList.add('hidden');
    }
  },
  hideMenu(): void {
    document.getElementById('overlay')!.classList.add('hidden');
    document.getElementById('hud')!.classList.remove('hidden');
  },
  setHUD(score: number, lives: number): void {
    document.getElementById('score')!.textContent = String(score);
    document.getElementById('lives')!.textContent = '❤️'.repeat(Math.max(0, lives));
  }
};