// 模拟状态（与渲染分离）：分数、生命、生成调度、难度全部归这里管
export type ItemKind = 'fish' | 'goldfish' | 'bomb';

export class GameState {
  score = 0;
  lives = 3;
  catchCount = 0;
  gameOver = false;
  private spawnT = 0.7;
  private level = 1;

  reset(): void {
    this.score = 0;
    this.lives = 3;
    this.catchCount = 0;
    this.gameOver = false;
    this.spawnT = 0.7;
    this.level = 1;
  }

  get levelNum(): number { return this.level; }

  /** 每帧调用，返回"到点该生成什么" */
  tick(dt: number): ItemKind | null {
    if (this.gameOver) return null;
    this.spawnT -= dt;
    if (this.spawnT <= 0) {
      this.spawnT = this.interval();
      this.level = 1 + Math.floor(this.catchCount / 10);
      return this.decide();
    }
    return null;
  }

  private interval(): number {
    return Math.max(0.5, 1.35 - this.level * 0.09);
  }

  private decide(): ItemKind {
    const r = Math.random();
    const bombP = Math.min(0.32, 0.20 + this.level * 0.015);
    const goldP = 0.10;
    if (r < bombP) return 'bomb';
    if (r < bombP + goldP) return 'goldfish';
    return 'fish';
  }

  addCatch(kind: ItemKind): void {
    this.catchCount++;
    this.score += kind === 'goldfish' ? 50 : 10;
    this.level = 1 + Math.floor(this.catchCount / 10);
  }

  hitBomb(): void {
    this.lives--;
    if (this.lives <= 0) this.gameOver = true;
  }
}