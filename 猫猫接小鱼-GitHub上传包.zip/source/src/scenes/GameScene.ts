import Phaser from 'phaser';
import { GameState, ItemKind } from '../systems/GameState';
import { ui } from '../systems/DOM';
import { ASSETS } from './BootScene';

export class GameScene extends Phaser.Scene {
  private state = new GameState();
  private cat!: Phaser.Physics.Arcade.Sprite;
  private items!: Phaser.Physics.Arcade.Group;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys & Record<string, Phaser.Input.Keyboard.Key>;
  private moveTarget: number | null = null;
  private active = false;
  private lastScore = -1;
  private lastLives = -1;

  constructor() { super('Game'); }

  create(): void {
    const { width, height } = this.scale;

    // 背景：天空渐变 + 云朵
    const bg = this.add.graphics();
    bg.fillGradientStyle(0x8ecbff, 0x8ecbff, 0xfdf6d8, 0xfdf6d8, 1);
    bg.fillRect(0, 0, width, height);
    for (let i = 0; i < 5; i++) {
      const x = Phaser.Math.Between(30, width - 30);
      const y = Phaser.Math.Between(40, height * 0.5);
      const cloud = this.add.graphics();
      cloud.fillStyle(0xffffff, 0.85);
      cloud.fillCircle(x, y, 22);
      cloud.fillCircle(x + 24, y + 4, 16);
      cloud.fillCircle(x - 24, y + 6, 15);
      this.tweens.add({ targets: cloud, x: x + 26, duration: 6000 + i * 800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    this.cat = this.physics.add.sprite(width / 2, height - 64, ASSETS.cat);
    this.cat.setScale(1.7);
    this.cat.setCollideWorldBounds(true);
    this.cat.setImmovable(true);

    this.items = this.physics.add.group();
    this.physics.add.overlap(this.cat, this.items, this.onCatch as Phaser.Types.Physics.Arcade.ArcadePhysicsCallback, undefined, this);

    this.cursors = this.input.keyboard!.addKeys('left,right,a,d') as never;

    this.input.on('pointerdown', (p: Phaser.Input.Pointer) => { this.moveTarget = p.x; });
    this.input.on('pointermove', (p: Phaser.Input.Pointer) => { if (p.isDown) this.moveTarget = p.x; });
    this.input.on('pointerup', () => { this.moveTarget = null; });

    ui.showMenu();
  }

  startGame(): void {
    this.state.reset();
    this.active = true;
    this.items.clear(true, true);
    this.lastScore = -1;
    this.lastLives = -1;
    this.moveTarget = null;
    ui.hideMenu();
    this.updateHUD();
  }

  update(_time: number, delta: number): void {
    if (!this.active) return;
    const dt = delta / 1000;
    const plan = this.state.tick(dt);
    if (plan) this.spawn(plan);

    // 输入 → 动作（映射集中在场景输入层）
    const speed = 400;
    let dir = 0;
    if (this.cursors.left.isDown || this.cursors.a.isDown) dir = -1;
    else if (this.cursors.right.isDown || this.cursors.d.isDown) dir = 1;
    if (this.moveTarget !== null) {
      const diff = this.moveTarget - this.cat.x;
      if (Math.abs(diff) > 8) dir = Math.sign(diff);
    }
    this.cat.setVelocityX(dir * speed);

    // 清理出屏物体
    this.items.getChildren().forEach((o) => {
      const s = o as Phaser.Physics.Arcade.Sprite;
      if (s.y > this.scale.height + 40) s.destroy();
    });

    this.updateHUD();

    if (this.state.gameOver) {
      this.active = false;
      this.cat.setVelocityX(0);
      ui.showMenu(this.state.score);
    }
  }

  private spawn(kind: ItemKind): void {
    const x = Phaser.Math.Between(40, this.scale.width - 40);
    const key = kind === 'goldfish' ? ASSETS.goldfish : kind === 'bomb' ? ASSETS.bomb : ASSETS.fish;
    const s = this.items.create(x, -24, key) as Phaser.Physics.Arcade.Sprite;
    s.setData('kind', kind);
    (s.body as Phaser.Physics.Arcade.Body).setAllowGravity(false);
    const speed = Phaser.Math.Between(110, 200) + this.state.levelNum * 18;
    s.setVelocityY(speed);
    if (kind === 'fish' || kind === 'goldfish') {
      s.setScale(1.15);
      this.tweens.add({ targets: s, angle: kind === 'fish' ? 8 : -8, duration: 380, yoyo: true, repeat: -1 });
    } else {
      this.tweens.add({ targets: s, angle: [0, 6, 0, -6, 0], duration: 700, repeat: -1 });
    }
  }

  private onCatch(_cat: Phaser.GameObjects.GameObject, itemObj: Phaser.GameObjects.GameObject): void {
    const item = itemObj as Phaser.Physics.Arcade.Sprite;
    const kind = item.getData('kind') as ItemKind;
    if (kind === 'bomb') {
      this.state.hitBomb();
      this.cameras.main.shake(140, 0.008);
      this.cameras.main.flash(140, 220, 70, 70);
    } else {
      this.state.addCatch(kind);
      this.cameras.main.flash(80, 200, 255, 190);
      this.floatText('+' + (kind === 'goldfish' ? 50 : 10), item.x, item.y);
    }
    item.destroy();
  }

  private floatText(text: string, x: number, y: number): void {
    const t = this.add.text(x, y, text, { fontFamily: 'Arial', fontSize: '20px', color: '#d97a2b', fontStyle: 'bold' }).setOrigin(0.5);
    this.tweens.add({ targets: t, y: y - 40, alpha: 0, duration: 650, onComplete: () => t.destroy() });
  }

  private updateHUD(): void {
    if (this.lastScore !== this.state.score || this.lastLives !== this.state.lives) {
      this.lastScore = this.state.score;
      this.lastLives = this.state.lives;
      ui.setHUD(this.state.score, this.state.lives);
    }
  }
}