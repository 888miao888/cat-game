import Phaser from 'phaser';

// 资源清单：稳定的 manifest key，避免到处写文件路径
export const ASSETS = {
  cat: 'cat', fish: 'fish', goldfish: 'goldfish', bomb: 'bomb', heart: 'heart'
} as const;

export class BootScene extends Phaser.Scene {
  constructor() { super('Boot'); }

  preload(): void {
    this.load.image(ASSETS.cat, 'assets/characters/cat.png');
    this.load.image(ASSETS.fish, 'assets/characters/fish.png');
    this.load.image(ASSETS.goldfish, 'assets/characters/goldfish.png');
    this.load.image(ASSETS.bomb, 'assets/characters/bomb.png');
    this.load.image(ASSETS.heart, 'assets/characters/heart.png');
  }

  create(): void {
    this.scene.start('Game');
  }
}