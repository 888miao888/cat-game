from PIL import Image
import os

BASE = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'public', 'assets'))
os.makedirs(os.path.join(BASE, 'characters'), exist_ok=True)
os.makedirs(os.path.join(BASE, 'environment'), exist_ok=True)

PAL = {
 'O': (242,163,60,255),   # orange
 'D': (201,123,36,255),   # dark orange
 'W': (255,243,220,255),  # cream
 'B': (58,43,32,255),     # black
 'P': (255,158,187,255),  # pink
 'Y': (255,222,89,255),   # yellow
 'S': (110,170,230,255),  # blue
 'R': (220,80,60,255),    # red
 'G': (90,90,90,255),     # gray
 'E': (80,80,80,255),     # dark gray
}

def render(name, sub, grid, scale):
    h = len(grid); w = len(grid[0])
    img = Image.new('RGBA', (w*scale, h*scale), (0,0,0,0))
    px = img.load()
    for y,row in enumerate(grid):
        for x,ch in enumerate(row):
            if ch in PAL and ch != '.':
                c = PAL[ch]
                for dy in range(scale):
                    for dx in range(scale):
                        px[x*scale+dx, y*scale+dy] = c
    p = os.path.join(BASE, sub, name)
    img.save(p)
    print('saved', p, img.size)

# Cat (player) - front facing cute cat
cat = [
"................",
"...OOO....OOO...",
"..OOOO...OOOO...",
"..OOOOOOOOOOO...",
".OOOOOOOOOOOOO..",
".OOWWWWWWWWOOO..",
".OWWWWWWWWWWOO..",
".OWBWWWWWWBWO...",
".OWWWWWWWWWWO...",
".OWWWWPWWWWWO...",
".OWWWWWWWWWWO...",
".OWWWWWWWWWWO...",
".OOWWWWWWWWOO...",
"..OOOOWWOOOO....",
"..DDDDDDDDDD....",
"................",
]
render('cat.png', 'characters', cat, 4)

# Fish
fish = [
"..OO..SSSSSSSS..",
".OOO.SSSSSSSSSS.",
"OOO.SSSSSSBSSSS.",
"OOO.SSSSSSSSSSS.",
".OOO.SSSSSSSSSS.",
"..OO..SSSSSSSS..",
]
render('fish.png', 'characters', fish, 3)

# Golden fish (bonus)
gold = [
"..OO..YYYYYYYY..",
".OOO.YYYYYYYYYY.",
"OOO.YYYYYYBYYYY.",
"OOO.YYYYYYYYYYY.",
".OOO.YYYYYYYYYY.",
"..OO..YYYYYYYY..",
]
render('goldfish.png', 'characters', gold, 3)

# Bomb
bomb = [
"................",
"......RR........",
".....RR.........",
".....YY.........",
"................",
"....BBBBB.......",
"...BBBBBBB......",
"..BBBBBBBBB.....",
"..BBWBBBBBBB....",
".BBBBBBBBBBBB...",
".BBBBBBBBBBBB...",
".BBBBBBBBBBBB...",
".BBEBBBBBBBBB...",
".BBBBBBBBBBBB...",
"..BBBBBBBBBB....",
"..BBBBBBBBB.....",
]
render('bomb.png', 'characters', bomb, 3)

# Heart (life icon)
heart = [
".PP...PP.",
"PPPP.PPPP",
"PPPPPPPPP",
"PPPPPPPPP",
".PPPPPPP.",
"..PPPPP..",
"...PPP...",
"....P....",
]
render('heart.png', 'characters', heart, 3)

print('done')