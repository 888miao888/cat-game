from PIL import Image
import os
A = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'public', 'assets', 'characters'))
names = ['cat.png','fish.png','goldfish.png','bomb.png','heart.png']
ims = [Image.open(os.path.join(A,n)).convert('RGBA') for n in names]
W = 280; H = 100; pad = 12
canvas = Image.new('RGBA',(W,H),(245,245,245,255))
x = pad
for im in names and ims:
    # scale to fit height ~70
    scale = 70 / max(im.size)
    im2 = im.resize((max(1,int(im.width*scale)), max(1,int(im.height*scale))), Image.NEAREST)
    canvas.alpha_composite(im2,(x, (H-im2.height)//2))
    x += im2.width + pad
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sprites-preview.png')
canvas.convert('RGB').save(out)
print('saved', out)